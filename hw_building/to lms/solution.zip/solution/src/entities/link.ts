export const LinkEntity = 'LinkEntity';
