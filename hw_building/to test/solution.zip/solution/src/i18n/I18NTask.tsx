
import React from 'react';
import i18n from "./i18n";

export default () => {
    return (
        <div>
            {i18n('test')}
        </div>
    );
}
